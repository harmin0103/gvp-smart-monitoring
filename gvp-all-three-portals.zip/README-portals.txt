GVP WATCH — Citizen and Cleaning Crew Portals

Files:
- citizen.html: citizen issue reporting and complaint tracking prototype
- cleaning-crew.html: cleaning task list and work update prototype

How to use:
1. Keep these files in the same project folder as your existing admin index.html.
2. Open citizen.html or cleaning-crew.html in a browser.
3. Upload the full project folder to your GitHub Pages repository.

Important:
These are front-end demonstrations. Form submissions and status changes are held in page memory only. They are not connected to the admin dashboard, municipal staff, live maps, a database, or a notification service. For a real deployment, add authentication, backend APIs, secure photo storage, validated location capture, and role-based access.

Admin portal:
- index.html is the original GVP Smart Monitoring admin dashboard.
- citizen.html is the citizen reporting portal.
- cleaning-crew.html is the cleaning crew task portal.

All three pages are front-end demo files. They are not connected to a shared backend or live data source.
